#ifndef __TIM_H
#define __TIM_H


void Timer3_Init(uint16_t TIM_Period,uint16_t TIM_Prescaler);

#endif


