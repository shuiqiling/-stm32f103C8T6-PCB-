#ifndef __KEY_H
#define __KEY_H

void KEY_Init(void);
char KEY_check1(void);
char KEY_check2(void);

#endif
