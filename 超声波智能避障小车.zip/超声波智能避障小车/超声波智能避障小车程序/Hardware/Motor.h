#ifndef __Motor_H
#define __Motor_H

void Motor_Init(void);

void Motor_LSpeed(int8_t speed);
void Motor_RSpeed(int8_t speed);

#endif



