#ifndef __BUZ_H
#define __BUZ_H

void BUZ_Init(void);

#endif
