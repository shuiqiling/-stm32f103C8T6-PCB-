#ifndef __Encoder_H
#define __Encoder_H
void Encoder_Init(void);
int16_t Encoder_Getcount(void);
int16_t Encoder_GetSpeed(void);
#endif


