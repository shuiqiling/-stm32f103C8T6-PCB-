#include "stm32f10x.h"                  // Device header
#include "HAL.h"
void HAL_PWM_Init(void)
{
	PWM_Init();
}



