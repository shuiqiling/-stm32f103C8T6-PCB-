#ifndef __HAL_Motor_H
#define __HAL_Motor_H

void HAL_Motor_Init(void);

void HAL_Motor_RSpeed(int8_t Rspeed);
void HAL_Motor_LSpeed(int8_t Lspeed);

#endif


