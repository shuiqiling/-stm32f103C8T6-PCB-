#ifndef __HAL_PWM_H
#define __HAL_PWM_H

void HAL_PWM_Init(void);


#endif


