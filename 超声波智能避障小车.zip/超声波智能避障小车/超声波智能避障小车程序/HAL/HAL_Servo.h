#ifndef __HAL_Servo_H
#define __HAL_Servo_H

void HAL_Servo_Init(void);
void HAL_Servo_SetAngle(float Angle);


#endif


